// -*- C++ -*-
// Copyright (C) Dmitry Igrishin
// For conditions of distribution and use, see files LICENSE.txt or fcgi.hpp

#define DMITIGR_FCGI_HEADER_ONLY
#define DMITIGR_FCGI_BUILDING
#include "dmitigr/fcgi.hpp"
