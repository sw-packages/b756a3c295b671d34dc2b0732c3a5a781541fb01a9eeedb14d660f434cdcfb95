// -*- C++ -*-
// Copyright (C) Dmitry Igrishin
// For conditions of distribution and use, see files LICENSE.txt or fcgi.hpp

#ifdef DMITIGR_FCGI_NOMINMAX
#undef DMITIGR_FCGI_NOMINMAX
#undef NOMINMAX
#endif

#ifdef DMITIGR_FCGI_INLINE
#undef DMITIGR_FCGI_INLINE
#endif
